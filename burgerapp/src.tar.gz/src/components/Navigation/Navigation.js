import React from 'react';

const navigation = (props) => (
    <header>
        <div>MENU</div>
        <div>MENU</div>
        <nav>
        </nav>
    </header>
)

export default navigation;